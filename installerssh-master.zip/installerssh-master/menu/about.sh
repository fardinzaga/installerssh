#!/bin/bash

clear
echo -e "#======================================#"
echo -e "#  Script Auto Install SSH & OpenVPN   #"
echo -e "#--------------------------------------#"
echo -e "# For Debian 9 & 10 64 bit             #"
echo -e "# Mod By Fauzanvpn                     #"
